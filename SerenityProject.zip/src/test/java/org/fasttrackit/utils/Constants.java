package org.fasttrackit.utils;

public class Constants {

    public static final String USER_EMAIL = "cosmin@fasttrackit.org";
    public static final String USER_PASSWORD = "123456";
}
